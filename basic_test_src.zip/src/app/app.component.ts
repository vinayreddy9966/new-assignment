import {Component, OnInit} from '@angular/core';
import {ApiService} from './services/api-service.service';
import {FormControl, Validators} from '@angular/forms';
import {DatePipe} from '@angular/common';

@Component({
    selector: 'app-root',
    templateUrl: './app.component.html',
    styleUrls: ['./app.component.scss']
})

export class AppComponent implements OnInit {
    title = 'fhir-app-test';
    patients = [];
    responseTime = 0;
    isLoading = false;
    nameControl: FormControl;
    dateControl: FormControl;

    constructor(
        private datePipe: DatePipe,
        private apiService: ApiService
    ) {
    }

    initForm() {
        this.nameControl = new FormControl('', [
            Validators.required,
            Validators.maxLength(50),
            Validators.pattern('^[a-zA-Z ]*$')
        ]);
        this.dateControl = new FormControl('', [
            Validators.required,
            Validators.pattern('\\d{4}/\\d{2}/\\d{2}')
        ]);
    }

    ngOnInit() {
        this.initForm();
        const startTime = new Date().getTime();
        this.isLoading = true;
        this.apiService.getPatients().subscribe(
            (data: any) => {
                this.isLoading = false;
                const endTime = new Date().getTime();
                this.responseTime = (endTime - startTime);
                this.patients = data.entry as any[];
                console.log(data);
                this.patients = this.patients.sort((a: any, b: any) => {
                    return (new Date(a.resource.birthDate as string).getTime() - new Date(b.resource.birthDate as string).getTime());
                });
            }
        );
    }

    search() {
        const startTime = new Date().getTime();
        let name = '';
        let date = '';
        if (this.nameControl.valid) {
            name = this.nameControl.value;
        }
        if (this.dateControl.valid) {
            const dateObj = new Date(this.dateControl.value);
            date = this.datePipe.transform(dateObj, 'yyyy-MM-dd');
        }
        if (name || date) {
            this.isLoading = true;
            this.apiService.getSearchPatients(name, date).subscribe(
                (data: any) => {
                    this.isLoading = false;
                    const endTime = new Date().getTime();
                    this.responseTime = (endTime - startTime);
                    this.patients = data.entry as any[];
                    console.log(data);
                    this.patients = this.patients.sort((a: any, b: any) => {
                        return (new Date(a.resource.birthDate as string).getTime() - new Date(b.resource.birthDate as string).getTime());
                    });
                }
            );
        }
    }
}


